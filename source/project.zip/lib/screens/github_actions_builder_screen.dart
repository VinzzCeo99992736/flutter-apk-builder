import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/app_theme.dart';
import '../core/constants.dart';
import '../models/build_step_model.dart';
import '../services/github_service.dart';
import '../widgets/info_banner.dart';
import '../widgets/log_console.dart';
import '../widgets/step_chip.dart';

class GithubActionsBuilderScreen extends StatefulWidget {
  const GithubActionsBuilderScreen({super.key});

  @override
  State<GithubActionsBuilderScreen> createState() => _GithubActionsBuilderScreenState();
}

class _GithubActionsBuilderScreenState extends State<GithubActionsBuilderScreen> {
  final TextEditingController _tokenCtrl = TextEditingController();
  bool _tokenObscured = true;
  bool _tokenSaved = false;

  PlatformFile? _pickedZip;

  bool _isBuilding = false;
  bool _cancelled = false;
  double _progress = 0;
  int _currentStepIndex = -1;
  List<BuildStepModel> _steps = buildDefaultSteps();
  final List<String> _logs = [];

  String? _repoOwner;
  final String _repoName = AppConstants.defaultRepoName;

  @override
  void initState() {
    super.initState();
    _loadSavedToken();
  }

  Future<void> _loadSavedToken() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(AppConstants.prefsGithubToken);
    if (saved != null && saved.isNotEmpty) {
      setState(() {
        _tokenCtrl.text = saved;
        _tokenSaved = true;
      });
    }
  }

  Future<void> _saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefsGithubToken, token);
    setState(() => _tokenSaved = true);
  }

  Future<void> _clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConstants.prefsGithubToken);
    setState(() {
      _tokenCtrl.clear();
      _tokenSaved = false;
    });
  }

  Future<void> _pickZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      withData: true,
    );
    if (result != null && result.files.isNotEmpty) {
      final file = result.files.first;
      if ((file.size) > AppConstants.maxZipSizeBytes) {
        _showSnack("Ukuran ZIP melebihi batas 50 MB.");
        return;
      }
      setState(() => _pickedZip = file);
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _log(String msg) {
    final now = DateTime.now();
    final ts =
        "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    setState(() => _logs.add("$ts $msg"));
  }

  void _setStep(int index, StepStatus status) {
    setState(() {
      _currentStepIndex = index;
      _steps[index].status = status;
      _progress = (index + (status == StepStatus.done ? 1 : 0.4)) / _steps.length;
    });
  }

  Future<void> _startBuild() async {
    final token = _tokenCtrl.text.trim();
    if (token.isEmpty) {
      _showSnack("Masukkan GitHub Personal Access Token dulu.");
      return;
    }
    if (_pickedZip == null || _pickedZip!.bytes == null) {
      _showSnack("Pilih file ZIP project Flutter kamu dulu.");
      return;
    }

    await _saveToken(token);

    setState(() {
      _isBuilding = true;
      _cancelled = false;
      _progress = 0;
      _logs.clear();
      _steps = buildDefaultSteps();
    });

    final service = GithubService(token);
    _log("GitHub Actions Flutter Builder");
    _log("Source: ZIP upload dari perangkat");
    _log("―――――――――――――――――――――――――――");

    try {
      // STEP 1: Validasi Token
      _setStep(0, StepStatus.running);
      _log("▶ Validasi Token");
      final user = await service.validateToken();
      _repoOwner = user.login;
      _log("  User   : ${user.login}");
      _log("  Plan   : ${user.plan}");
      if (_cancelled) return _handleCancelled();
      _setStep(0, StepStatus.done);
      _log("✓ Validasi Token");
      _log("  Token tersimpan lokal ✓");

      // STEP 2: Siapkan Repo
      _setStep(1, StepStatus.running);
      _log("▶ Siapkan Repo");
      await service.ensureRepo(_repoOwner!, _repoName);
      _log("  Repo: $_repoOwner/$_repoName");
      if (_cancelled) return _handleCancelled();
      _setStep(1, StepStatus.done);
      _log("✓ Siapkan Repo");

      // STEP 3: Upload ZIP
      _setStep(2, StepStatus.running);
      _log("▶ Upload ZIP");
      final Uint8List zipBytes = _pickedZip!.bytes!;
      _log("  File   : ${_pickedZip!.name}");
      _log("  Ukuran : ${(zipBytes.length / (1024 * 1024)).toStringAsFixed(1)} MB");
      _log("  Encoding base64 & upload ke repo…");
      await service.uploadZip(_repoOwner!, _repoName, zipBytes);
      if (_cancelled) return _handleCancelled();
      _setStep(2, StepStatus.done);
      _log("✓ Upload ZIP");

      // STEP 4: Push Workflow
      _setStep(3, StepStatus.running);
      _log("▶ Push Workflow");
      await service.pushWorkflow(_repoOwner!, _repoName);
      if (_cancelled) return _handleCancelled();
      _setStep(3, StepStatus.done);
      _log("✓ Push Workflow");

      // STEP 5: Trigger Build
      _setStep(4, StepStatus.running);
      _log("▶ Trigger Build");
      await service.triggerWorkflowDispatch(_repoOwner!, _repoName);
      _log("  Menunggu GitHub Actions memulai run…");
      await Future.delayed(const Duration(seconds: 6));
      if (_cancelled) return _handleCancelled();
      _setStep(4, StepStatus.done);
      _log("✓ Trigger Build");

      // STEP 6: Queue & Setup — cari run terbaru & tunggu sampai in_progress
      _setStep(5, StepStatus.running);
      _log("▶ Queue & Setup");
      WorkflowRun run = await service.findLatestRun(_repoOwner!, _repoName);
      _log("  Run ID : ${run.id}");
      while (run.status == "queued") {
        if (_cancelled) return _handleCancelled();
        await Future.delayed(const Duration(seconds: 5));
        run = await service.getRun(_repoOwner!, _repoName, run.id);
      }
      _setStep(5, StepStatus.done);
      _log("✓ Queue & Setup");

      // STEP 7: Flutter Build — poll sampai completed
      _setStep(6, StepStatus.running);
      _log("▶ Flutter Build");
      _log("  Building di Ubuntu runner, estimasi 5-15 menit…");
      while (run.status != "completed") {
        if (_cancelled) return _handleCancelled();
        await Future.delayed(const Duration(seconds: 8));
        run = await service.getRun(_repoOwner!, _repoName, run.id);
      }
      if (run.conclusion != "success") {
        _setStep(6, StepStatus.error);
        _log("✗ Flutter Build gagal (conclusion: ${run.conclusion}).");
        _log("  Cek log lengkap di: ${run.htmlUrl}");
        _finishBuilding();
        return;
      }
      _setStep(6, StepStatus.done);
      _log("✓ Flutter Build");

      // STEP 8: Ambil APK
      _setStep(7, StepStatus.running);
      _log("▶ Ambil APK");
      final artifactZipBytes = await service.downloadApkArtifactZip(_repoOwner!, _repoName, run.id);
      final apkPath = await _extractApkFromArtifact(artifactZipBytes);
      _setStep(7, StepStatus.done);
      _log("✓ Ambil APK");
      _log("  Tersimpan: $apkPath");

      _finishBuilding();
      _showSnack("Build selesai! APK siap di-install.");
      if (apkPath != null) {
        OpenFilex.open(apkPath);
      }
    } catch (e) {
      if (_currentStepIndex >= 0 && _currentStepIndex < _steps.length) {
        _steps[_currentStepIndex].status = StepStatus.error;
      }
      _log("✗ Error: $e");
      _finishBuilding();
      _showSnack("Build gagal, cek log untuk detail.");
    }
  }

  Future<String?> _extractApkFromArtifact(Uint8List artifactZipBytes) async {
    final archive = ZipDecoder().decodeBytes(artifactZipBytes);
    final apkFile = archive.files.firstWhere(
      (f) => f.isFile && f.name.toLowerCase().endsWith('.apk'),
      orElse: () => throw GithubApiException("File APK tidak ditemukan di artifact."),
    );
    final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    final outPath = "${dir.path}/surya_builder_release.apk";
    final outFile = File(outPath);
    await outFile.writeAsBytes(apkFile.content as List<int>);
    return outPath;
  }

  void _handleCancelled() {
    _log("⏹ Build dibatalkan oleh user.");
    _finishBuilding();
  }

  void _finishBuilding() {
    setState(() => _isBuilding = false);
  }

  void _cancelBuild() {
    setState(() => _cancelled = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.chevron_left),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        title: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF0F6E73), Color(0xFF0B4A50)]),
                borderRadius: BorderRadius.circular(9),
              ),
              child: const Icon(Icons.bolt, color: AppColors.cyan, size: 18),
            ),
            const SizedBox(width: 10),
            const Text("GitHub Actions Builder"),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy_outlined, size: 20),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (!_isBuilding) _buildIntroCard(),
                    if (!_isBuilding) const SizedBox(height: 24),
                    if (_isBuilding) _buildRunUrlCard(),
                    if (_isBuilding) const SizedBox(height: 14),
                    if (_isBuilding) _buildProgressBar(),
                    if (_isBuilding) const SizedBox(height: 18),
                    Text(
                      "8 LANGKAH OTOMATIS VIA GITHUB API",
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: [for (final s in _steps) StepChip(step: s)]),
                    ),
                    const SizedBox(height: 20),
                    if (_isBuilding) LogConsole(lines: _logs),
                    if (!_isBuilding) ...[
                      _buildTokenSection(),
                      const SizedBox(height: 20),
                      _buildUploadZipSection(),
                      const SizedBox(height: 20),
                      InfoBanner(
                        icon: Icons.info_outline,
                        text:
                            "ZIP akan diupload ke repo GitHub kamu, kemudian diekstrak & di-build oleh GitHub Actions. Ukuran maksimal ±50 MB. Struktur ZIP: bisa root langsung atau satu folder di dalam.",
                      ),
                      InfoBanner(
                        icon: Icons.access_time,
                        tone: BannerTone.warning,
                        text:
                            "Estimasi build: 5-15 menit (Ubuntu runner)\nRepo public → gratis unlimited. Repo private → kuota 2.000 mnt/bln.",
                      ),
                      InfoBanner(
                        icon: Icons.notifications_none,
                        tone: BannerTone.warning,
                        text:
                            "Mode background aktif.\nBuild tetap lanjut walau app ditutup. Saat dibuka lagi, status dan log terakhir akan disambungkan otomatis.",
                      ),
                    ],
                  ],
                ),
              ),
            ),
            if (_isBuilding) _buildBottomBar(),
          ],
        ),
      ),
      bottomNavigationBar: !_isBuilding ? _buildStartButton() : null,
    );
  }

  Widget _buildIntroCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: AppColors.logoGradient),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.bolt, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(AppConstants.appName + " Actions Builder",
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                const Text(
                  "Tanpa VPS · Tanpa SSH · Cukup token GitHub\nUpload ZIP → build APK → notifikasi otomatis",
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13.5, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRunUrlCard() {
    final owner = _repoOwner ?? "…";
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              _Dot(color: AppColors.red),
              SizedBox(width: 6),
              _Dot(color: AppColors.orange),
              SizedBox(width: 6),
              _Dot(color: AppColors.green),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  "github.com/$owner/$_repoName",
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.textPrimary),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.cardBg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.cyan),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 10,
                      height: 10,
                      child: CircularProgressIndicator(strokeWidth: 1.6, color: AppColors.cyan),
                    ),
                    SizedBox(width: 6),
                    Text("Building", style: TextStyle(color: AppColors.cyan, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            _currentStepIndex >= 0 ? "${_steps[_currentStepIndex].label}…" : "Memulai…",
            style: const TextStyle(color: AppColors.cyan, fontSize: 12.5),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    final doneCount = _steps.where((s) => s.status == StepStatus.done).length;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text("$doneCount/${_steps.length}",
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            const Spacer(),
            Text("${(_progress * 100).clamp(0, 100).toStringAsFixed(0)}%",
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: _progress.clamp(0, 1),
            minHeight: 6,
            backgroundColor: AppColors.cardBorder,
            valueColor: const AlwaysStoppedAnimation(AppColors.cyan),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: const BoxDecoration(
        color: AppColors.bgDark2,
        border: Border(top: BorderSide(color: AppColors.cardBorder)),
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _cancelBuild,
              icon: const Icon(Icons.stop_circle_outlined, size: 18, color: AppColors.textSecondary),
              label: const Text("Batalkan", style: TextStyle(color: AppColors.textSecondary)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.cardBorder),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 2,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.cardBorder),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(strokeWidth: 1.8, color: AppColors.cyan),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "Sedang build… (${_currentStepIndex + 1}/${_steps.length} langkah)",
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTokenSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_tokenSaved)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.greenBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.greenBorder),
              ),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, color: AppColors.green, size: 18),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text("Token tersimpan di perangkat ini",
                        style: TextStyle(color: AppColors.green, fontWeight: FontWeight.w600)),
                  ),
                  TextButton(
                    onPressed: _clearToken,
                    style: TextButton.styleFrom(foregroundColor: AppColors.red),
                    child: const Text("Hapus"),
                  ),
                ],
              ),
            ),
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: AppColors.cyanDeep.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(Icons.widgets_outlined, color: AppColors.cyan, size: 18),
              ),
              const SizedBox(width: 10),
              const Text("GitHub Personal Access Token",
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 4),
          const Padding(
            padding: EdgeInsets.only(left: 44),
            child: Text("GHP Token · Settings › Developer Settings › PAT",
                style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppColors.bgDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: Row(
              children: [
                const Icon(Icons.lock_outline, size: 16, color: AppColors.textMuted),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _tokenCtrl,
                    obscureText: _tokenObscured,
                    style: const TextStyle(fontSize: 13, letterSpacing: 1),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 14),
                      hintText: "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                      hintStyle: TextStyle(color: AppColors.textMuted, fontSize: 12),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => setState(() => _tokenObscured = !_tokenObscured),
                  icon: Icon(_tokenObscured ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      size: 18, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.infoBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.infoBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.info_outline, size: 15, color: AppColors.cyan),
                    SizedBox(width: 6),
                    Text("Scope token yang dibutuhkan",
                        style: TextStyle(
                            color: AppColors.cyan, fontWeight: FontWeight.w700, fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 10),
                _scopeRow("repo", "Akses penuh ke repo (push workflow & ZIP)"),
                const SizedBox(height: 8),
                _scopeRow("workflow", "Buat & jalankan GitHub Actions workflow"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _scopeRow(String scope, String desc) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: AppColors.bgDark,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppColors.cardBorder),
          ),
          child: Text(scope,
              style: const TextStyle(color: AppColors.cyan, fontSize: 11.5, fontFamily: 'monospace')),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(desc, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
        ),
      ],
    );
  }

  Widget _buildUploadZipSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: AppColors.cyanDeep.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.folder_zip_outlined, color: AppColors.cyan, size: 16),
              ),
              const SizedBox(width: 10),
              const Text("Upload Project Flutter (ZIP)",
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 16),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _pickZip,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 32),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.cardBorder, width: 1.4),
                color: AppColors.bgDark,
              ),
              child: Column(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: AppColors.logoGradient),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.upload_file_outlined, color: Colors.white, size: 22),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _pickedZip == null ? "Ketuk untuk pilih file ZIP" : _pickedZip!.name,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Text(
                      _pickedZip == null
                          ? "ZIP project Flutter kamu (pubspec.yaml harus ada di dalam)"
                          : "${(_pickedZip!.size / (1024 * 1024)).toStringAsFixed(1)} MB · ketuk untuk ganti file",
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12.5, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStartButton() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
      decoration: const BoxDecoration(color: AppColors.bgDark),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: _startBuild,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: AppColors.ctaGradient),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: AppColors.cyan.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 6)),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.rocket_launch_outlined, color: Colors.white, size: 20),
              SizedBox(width: 10),
              Text("Mulai Build via GitHub Actions",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15.5)),
            ],
          ),
        ),
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;
  const _Dot({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }
}

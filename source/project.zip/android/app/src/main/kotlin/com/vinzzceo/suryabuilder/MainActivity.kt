package com.vinzzceo.suryabuilder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

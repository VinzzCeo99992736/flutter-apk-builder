import 'package:flutter/material.dart';
import '../core/app_theme.dart';

class LogConsole extends StatefulWidget {
  final List<String> lines;
  const LogConsole({super.key, required this.lines});

  @override
  State<LogConsole> createState() => _LogConsoleState();
}

class _LogConsoleState extends State<LogConsole> {
  final ScrollController _controller = ScrollController();

  @override
  void didUpdateWidget(covariant LogConsole oldWidget) {
    super.didUpdateWidget(oldWidget);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_controller.hasClients) {
        _controller.animateTo(
          _controller.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Color _colorFor(String line) {
    if (line.contains('✓') || line.toLowerCase().contains('sukses')) return AppColors.green;
    if (line.contains('✗') || line.toLowerCase().contains('gagal') || line.toLowerCase().contains('error')) {
      return AppColors.red;
    }
    if (RegExp(r'^\d{2}:\d{2}:\d{2}$').hasMatch(line.split(' ').first)) return AppColors.textMuted;
    if (line.trim().isEmpty) return AppColors.textMuted;
    return AppColors.purple;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 320,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.terminal, size: 16, color: AppColors.textMuted),
              const SizedBox(width: 6),
              const Text("github actions log",
                  style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
              const Spacer(),
              Text("${widget.lines.length} lines",
                  style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          const Divider(height: 1, color: AppColors.cardBorder),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              controller: _controller,
              itemCount: widget.lines.length,
              itemBuilder: (context, i) {
                final line = widget.lines[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    line,
                    style: TextStyle(
                      color: _colorFor(line),
                      fontSize: 12.5,
                      fontFamily: 'monospace',
                      height: 1.5,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

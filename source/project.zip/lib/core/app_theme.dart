import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Central color & text palette for SURYA BUILDER.
/// Cyberpunk dark navy theme with cyan / purple neon accents.
class AppColors {
  AppColors._();

  static const Color bgDark = Color(0xFF090C13);
  static const Color bgDark2 = Color(0xFF0D111B);
  static const Color cardBg = Color(0xFF12161F);
  static const Color cardBorder = Color(0xFF1E2530);

  static const Color cyan = Color(0xFF22D3EE);
  static const Color cyanDeep = Color(0xFF0EA5E9);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color blueAccent = Color(0xFF3B82F6);

  static const Color green = Color(0xFF22C55E);
  static const Color greenBg = Color(0xFF10241B);
  static const Color greenBorder = Color(0xFF1D6B43);

  static const Color orange = Color(0xFFF59E0B);
  static const Color orangeBg = Color(0xFF241A0D);
  static const Color orangeBorder = Color(0xFF6B4A1D);

  static const Color red = Color(0xFFEF4444);
  static const Color redBg = Color(0xFF2A1414);

  static const Color infoBg = Color(0xFF11192E);
  static const Color infoBorder = Color(0xFF25335A);

  static const Color textPrimary = Color(0xFFF3F6FB);
  static const Color textSecondary = Color(0xFF8992A6);
  static const Color textMuted = Color(0xFF5B6478);

  static const List<Color> logoGradient = [Color(0xFF34D3FF), Color(0xFF2563EB)];
  static const List<Color> ctaGradient = [Color(0xFF22D3EE), Color(0xFF3B82F6)];
}

class AppTheme {
  AppTheme._();

  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.comfortaaTextTheme(base.textTheme).apply(
      bodyColor: AppColors.textPrimary,
      displayColor: AppColors.textPrimary,
    );

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.bgDark,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.cyan,
        secondary: AppColors.purple,
        surface: AppColors.cardBg,
        error: AppColors.red,
      ),
      textTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.bgDark,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.comfortaa(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
      dividerColor: AppColors.cardBorder,
    );
  }
}

import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../models/build_step_model.dart';

class StepChip extends StatelessWidget {
  final BuildStepModel step;
  const StepChip({super.key, required this.step});

  @override
  Widget build(BuildContext context) {
    Color border;
    Color bg;
    Color fg;
    Widget leading;

    switch (step.status) {
      case StepStatus.done:
        border = AppColors.greenBorder;
        bg = AppColors.greenBg;
        fg = AppColors.green;
        leading = Icon(Icons.check, size: 16, color: fg);
        break;
      case StepStatus.running:
        border = AppColors.cyan;
        bg = AppColors.cardBg;
        fg = AppColors.cyan;
        leading = SizedBox(
          width: 14,
          height: 14,
          child: CircularProgressIndicator(strokeWidth: 2, color: fg),
        );
        break;
      case StepStatus.error:
        border = AppColors.red;
        bg = AppColors.redBg;
        fg = AppColors.red;
        leading = Icon(Icons.close, size: 16, color: fg);
        break;
      case StepStatus.pending:
        border = AppColors.cardBorder;
        bg = AppColors.cardBg;
        fg = AppColors.textSecondary;
        leading = Icon(step.icon, size: 16, color: fg);
        break;
    }

    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: border, width: 1.3),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          leading,
          const SizedBox(width: 8),
          Text(
            step.label,
            style: TextStyle(color: fg, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

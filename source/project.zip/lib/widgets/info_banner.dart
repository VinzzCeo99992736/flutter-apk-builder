import 'package:flutter/material.dart';
import '../core/app_theme.dart';

enum BannerTone { info, warning }

class InfoBanner extends StatelessWidget {
  final IconData icon;
  final String text;
  final BannerTone tone;

  const InfoBanner({
    super.key,
    required this.icon,
    required this.text,
    this.tone = BannerTone.info,
  });

  @override
  Widget build(BuildContext context) {
    final bool isInfo = tone == BannerTone.info;
    final Color bg = isInfo ? AppColors.infoBg : AppColors.orangeBg;
    final Color border = isInfo ? AppColors.infoBorder : AppColors.orangeBorder;
    final Color fg = isInfo ? AppColors.cyan : AppColors.orange;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: fg),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(color: fg, fontSize: 13, height: 1.4, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}

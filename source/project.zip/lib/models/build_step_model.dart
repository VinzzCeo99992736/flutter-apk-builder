import 'package:flutter/material.dart';

enum StepStatus { pending, running, done, error }

class BuildStepModel {
  final String id;
  final String label;
  final IconData icon;
  StepStatus status;

  BuildStepModel({
    required this.id,
    required this.label,
    required this.icon,
    this.status = StepStatus.pending,
  });
}

/// The canonical 8 steps shown as chips in the UI:
/// Validasi Token, Siapkan Repo, Upload ZIP, Push Workflow,
/// Trigger Build, Queue & Setup, Flutter Build, Ambil APK.
List<BuildStepModel> buildDefaultSteps() {
  return [
    BuildStepModel(id: "validate_token", label: "Validasi Token", icon: Icons.verified_outlined),
    BuildStepModel(id: "prepare_repo", label: "Siapkan Repo", icon: Icons.folder_outlined),
    BuildStepModel(id: "upload_zip", label: "Upload ZIP", icon: Icons.file_upload_outlined),
    BuildStepModel(id: "push_workflow", label: "Push Workflow", icon: Icons.code_outlined),
    BuildStepModel(id: "trigger_build", label: "Trigger Build", icon: Icons.play_circle_outline),
    BuildStepModel(id: "queue_setup", label: "Queue & Setup", icon: Icons.hourglass_bottom_outlined),
    BuildStepModel(id: "flutter_build", label: "Flutter Build", icon: Icons.developer_mode_outlined),
    BuildStepModel(id: "fetch_apk", label: "Ambil APK", icon: Icons.download_outlined),
  ];
}

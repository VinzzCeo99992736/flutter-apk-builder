import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../core/constants.dart';

class GithubApiException implements Exception {
  final String message;
  GithubApiException(this.message);
  @override
  String toString() => message;
}

class GithubUser {
  final String login;
  final String plan;
  GithubUser({required this.login, required this.plan});
}

class WorkflowRun {
  final int id;
  final String status; // queued, in_progress, completed
  final String? conclusion; // success, failure, cancelled...
  final String htmlUrl;

  WorkflowRun({
    required this.id,
    required this.status,
    required this.conclusion,
    required this.htmlUrl,
  });

  factory WorkflowRun.fromJson(Map<String, dynamic> json) {
    return WorkflowRun(
      id: json['id'] as int,
      status: json['status'] as String,
      conclusion: json['conclusion'] as String?,
      htmlUrl: json['html_url'] as String,
    );
  }
}

/// Wraps the GitHub REST API v3 calls needed to push a Flutter project
/// zip into a repo, trigger the Actions build workflow, watch its
/// progress, and download the resulting APK artifact.
class GithubService {
  static const String _base = "https://api.github.com";

  final String token;
  GithubService(this.token);

  Map<String, String> get _headers => {
        "Authorization": "Bearer $token",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
      };

  /// STEP 1: Validasi Token — GET /user
  Future<GithubUser> validateToken() async {
    final res = await http.get(Uri.parse("$_base/user"), headers: _headers);
    if (res.statusCode != 200) {
      throw GithubApiException("Token tidak valid atau tidak punya akses (${res.statusCode}).");
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    return GithubUser(login: data['login'] as String, plan: (data['plan']?['name'] ?? 'free') as String);
  }

  /// STEP 2: Siapkan Repo — cek repo ada, kalau belum buat baru (public).
  Future<void> ensureRepo(String owner, String repoName) async {
    final check = await http.get(Uri.parse("$_base/repos/$owner/$repoName"), headers: _headers);
    if (check.statusCode == 200) return; // repo sudah ada

    final create = await http.post(
      Uri.parse("$_base/user/repos"),
      headers: _headers,
      body: jsonEncode({
        "name": repoName,
        "private": false,
        "auto_init": true,
        "description": "Auto-created by SURYA BUILDER",
      }),
    );
    if (create.statusCode != 201) {
      throw GithubApiException("Gagal membuat repo (${create.statusCode}): ${create.body}");
    }
    // beri jeda singkat agar repo baru siap menerima commit
    await Future.delayed(const Duration(seconds: 2));
  }

  Future<String?> _getFileSha(String owner, String repo, String path) async {
    final res = await http.get(
      Uri.parse("$_base/repos/$owner/$repo/contents/$path"),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return data['sha'] as String?;
    }
    return null;
  }

  Future<void> _putFile({
    required String owner,
    required String repo,
    required String path,
    required Uint8List bytes,
    required String message,
  }) async {
    final sha = await _getFileSha(owner, repo, path);
    final res = await http.put(
      Uri.parse("$_base/repos/$owner/$repo/contents/$path"),
      headers: _headers,
      body: jsonEncode({
        "message": message,
        "content": base64Encode(bytes),
        if (sha != null) "sha": sha,
      }),
    );
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw GithubApiException("Gagal upload $path (${res.statusCode}): ${res.body}");
    }
  }

  /// STEP 3: Upload ZIP project Flutter ke repo.
  Future<void> uploadZip(String owner, String repo, Uint8List zipBytes) async {
    await _putFile(
      owner: owner,
      repo: repo,
      path: AppConstants.zipPathInRepo,
      bytes: zipBytes,
      message: "Upload ZIP project via SURYA BUILDER",
    );
  }

  /// STEP 4: Push workflow file GitHub Actions.
  Future<void> pushWorkflow(String owner, String repo) async {
    await _putFile(
      owner: owner,
      repo: repo,
      path: AppConstants.workflowPath,
      bytes: Uint8List.fromList(utf8.encode(AppConstants.workflowYaml)),
      message: "Setup build workflow via SURYA BUILDER",
    );
  }

  /// STEP 5: Trigger Build — panggil workflow_dispatch secara eksplisit
  /// (push ke ZIP juga sudah memicu, ini sebagai jaminan tambahan).
  Future<void> triggerWorkflowDispatch(String owner, String repo) async {
    final fileName = AppConstants.workflowPath.split('/').last;
    final res = await http.post(
      Uri.parse("$_base/repos/$owner/$repo/actions/workflows/$fileName/dispatches"),
      headers: _headers,
      body: jsonEncode({"ref": "main"}),
    );
    // 204 = sukses. 404 kadang muncul sesaat setelah file baru dipush,
    // dalam hal itu kita cukup andalkan trigger `push` di step upload.
    if (res.statusCode != 204 && res.statusCode != 404) {
      throw GithubApiException("Gagal trigger workflow (${res.statusCode}): ${res.body}");
    }
  }

  /// STEP 6/7: Cari run terbaru lalu poll status-nya sampai selesai.
  Future<WorkflowRun> findLatestRun(String owner, String repo) async {
    final res = await http.get(
      Uri.parse("$_base/repos/$owner/$repo/actions/runs?per_page=1"),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw GithubApiException("Gagal ambil daftar run (${res.statusCode}).");
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final runs = data['workflow_runs'] as List<dynamic>;
    if (runs.isEmpty) {
      throw GithubApiException("Belum ada workflow run yang terdeteksi.");
    }
    return WorkflowRun.fromJson(runs.first as Map<String, dynamic>);
  }

  Future<WorkflowRun> getRun(String owner, String repo, int runId) async {
    final res = await http.get(
      Uri.parse("$_base/repos/$owner/$repo/actions/runs/$runId"),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw GithubApiException("Gagal cek status run (${res.statusCode}).");
    }
    return WorkflowRun.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  /// STEP 8: Ambil APK — cari artifact & download bytes-nya (zip berisi apk).
  Future<Uint8List> downloadApkArtifactZip(String owner, String repo, int runId) async {
    final listRes = await http.get(
      Uri.parse("$_base/repos/$owner/$repo/actions/runs/$runId/artifacts"),
      headers: _headers,
    );
    if (listRes.statusCode != 200) {
      throw GithubApiException("Gagal ambil daftar artifact (${listRes.statusCode}).");
    }
    final data = jsonDecode(listRes.body) as Map<String, dynamic>;
    final artifacts = data['artifacts'] as List<dynamic>;
    if (artifacts.isEmpty) {
      throw GithubApiException("Artifact APK tidak ditemukan (build mungkin gagal).");
    }
    final artifactId = artifacts.first['id'];

    final dlRes = await http.get(
      Uri.parse("$_base/repos/$owner/$repo/actions/artifacts/$artifactId/zip"),
      headers: _headers,
    );
    if (dlRes.statusCode != 200) {
      throw GithubApiException("Gagal download artifact (${dlRes.statusCode}).");
    }
    return dlRes.bodyBytes;
  }
}

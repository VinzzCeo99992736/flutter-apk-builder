import 'package:flutter/material.dart';
import 'core/app_theme.dart';
import 'core/constants.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const SuryaBuilderApp());
}

class SuryaBuilderApp extends StatelessWidget {
  const SuryaBuilderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      home: const HomeScreen(),
    );
  }
}
